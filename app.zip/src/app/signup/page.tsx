import { Auth2 } from "@/components/auth-2";

export default function SignUpPage() {
  return (
    <>
      <Auth2 />
    </>
  );
}
